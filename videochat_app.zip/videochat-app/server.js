
const express = require('express');
const http = require('http');
const socketIO = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);
const port = 3000;

app.use(express.static(__dirname));

let waiting = { homme: null, femme: null };

io.on('connection', socket => {
    console.log('Nouvelle connexion');

    socket.on('join', role => {
        const counterpart = role === 'homme' ? 'femme' : 'homme';
        if (waiting[counterpart]) {
            const otherSocket = waiting[counterpart];
            waiting[counterpart] = null;
            socket.partner = otherSocket;
            otherSocket.partner = socket;
            socket.emit('ready');
            otherSocket.emit('ready');
        } else {
            waiting[role] = socket;
        }
    });

    socket.on('offer', data => {
        if (socket.partner) socket.partner.emit('offer', data);
    });

    socket.on('answer', data => {
        if (socket.partner) socket.partner.emit('answer', data);
    });

    socket.on('candidate', data => {
        if (socket.partner) socket.partner.emit('candidate', data);
    });

    socket.on('disconnect', () => {
        if (socket.partner) socket.partner.partner = null;
    });
});

server.listen(port, () => {
    console.log(`Serveur lancé sur http://localhost:${port}`);
});
